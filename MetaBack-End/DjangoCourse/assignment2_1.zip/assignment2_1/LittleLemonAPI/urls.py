from django.urls import path
from . import views
from .views import (
    ManagerLoginView,
    ItemOfTheDayView,
    AssignUserToDeliveryCrew,
    AssignOrderToDeliveryCrew,
    OrdersAssignedToCrew,
    BrowseMenuItemsView,
    CustomPageNumberPagination,
    CartListView,
)

urlpatterns = [
    path("manager-login/", ManagerLoginView.as_view(), name="manager-login"),
    path("item-of-the-day", ItemOfTheDayView.as_view(), name="item-of-the-day"),
    path(
        "assign-order-to-crew/<int:pk>/",
        AssignOrderToDeliveryCrew.as_view(),
        name="assign-order-to-crew",
    ),
    path(
        "orders-assigned-to-crew/",
        OrdersAssignedToCrew.as_view(),
        name="orders-assigned-to-crew",
    ),
    path(
        "assign-delivery-crew/<int:pk>/",
        AssignUserToDeliveryCrew.as_view(),
        name="assign-delivery-crew",
    ),
    path(
        "menu-items/category/<int:category_id>/",
        BrowseMenuItemsView.as_view(),
        name="browse-menu-items",
    ),
    path("menu-items/sort/", BrowseMenuItemsView.as_view(), name="sort-menu-items"),
    # Endpoint to access all Menu Items
    path("menu-items", views.MenuItemsView.as_view()),
    # Endpoint to a Specific Menu Item
    path("menu-items/<int:pk>", views.SingleMenuItemView.as_view()),
    # Endpoint to the Category
    path("category/", views.CategoriesView.as_view()),
    path("category/", views.CategoriesCreateView.as_view(), name="create-category"),
    # Endpoint to List Managers
    path("groups/manager/users", views.ManagerUserList.as_view(), name="manager-users"),
    # Endpoint to Assign a User to the Manager Group
    path(
        "groups/manager/users",
        views.AssignUserToManager.as_view(),
        name="assign-manager-user",
    ),
    # Endpoint to Remove a User from the Manager Group
    path(
        "groups/manager/users/<int:pk>",
        views.RemoveUserFromManager.as_view(),
        name="remove-manager-user",
    ),
    # Endpoint to List Delivery Crews
    path(
        "groups/delivery-crew/users",
        views.DeliveryCrewUserList.as_view(),
        name="crew-users",
    ),
    # Endpoint to Assign a User to the Crew Group
    path(
        "groups/delivery-crew/users",
        views.AssignUserToDeliveryCrew.as_view(),
        name="assign-crew-user",
    ),
    # Endpoint to Remove a User from the Crew Group
    path(
        "groups/delivery-crew/users/<int:pk>",
        views.RemoveUserFromDeliveryCrew.as_view(),
        name="remove-crew-user",
    ),
    # Endpoints to the Cart Management
    path("cart/menu-items", views.CartListView.as_view(), name="cart-list"),
    # path(
    #     "cart/menu-items/<int:pk>", views.CartDetailView.as_view(), name="cart-detail"
    # ),
    # Endpoints to the Order Management
    path("orders", views.OrderListCreateView.as_view(), name="order-list"),
    # path("orders/<int:order_id>", views.OrderDetailView.as_view(), name="order-detail"),
]
