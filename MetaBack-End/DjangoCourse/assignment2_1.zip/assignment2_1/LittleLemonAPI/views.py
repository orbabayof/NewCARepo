from django.shortcuts import render, get_object_or_404
from django.utils import timezone
from django.db.models import Sum, Q
from django.contrib.auth.models import User, Group
from django.contrib.auth.views import LoginView
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import IsAuthenticated
from rest_framework.pagination import PageNumberPagination
from rest_framework import status, generics, permissions
from .models import MenuItem, Category, Cart, Order, OrderItem
from .serializers import (
    MenuItemSerializer,
    MenuItemCreateSerializer,
    CategorySerializer,
    CategoryCreateSerializer,
    UserSerializer,
    AssignCrewSerializer,
    AssignManagerSerializer,
    CartSerializer,
    OrderCreateSerializer,
    OrderItemCreateSerializer,
    UpdateOrderStatusSerializer,
)
from decimal import Decimal


# Create a fine-grained access control to only Admininstrator and Manager
class IsAdminUser(permissions.BasePermission):
    def has_permission(self, request, view):
        return request.user and request.user.is_staff


class IsManagerOrAdminUsers(permissions.BasePermission):
    def has_permission(self, request, view):
        return (
            request.user.is_staff or request.user.groups.filter(name="Manager").exists()
        )


class IsCustomer(permissions.BasePermission):
    def has_permission(self, request, view):
        # Implement the logic to check if the user is a customer
        # You can customize this logic based on your requirements.
        return request.user.is_customer  # Adjust this condition as needed


# Create a permission class to restrict write (POST, PUT, PATCH, DELETE) to Manager,
# and allow ready-only access to other users
class IsManagerOrReadOnly(permissions.BasePermission):
    def has_permission(self, request, view):
        if request.method in permissions.SAFE_METHODS:
            # Allow read-only access for all users
            return True
        return request.user.groups.filter(name="Manager").exists()


# Create a permission class to allow only the user to have access and modify the orders he own
class IsOrderOwner(permissions.BasePermission):
    def has_object_permission(self, request, view, obj):
        # Check if the user is the owner of the order
        return obj.user == request.user


class ManagerLoginView(LoginView):
    template_name = "manager_login.html"  # create an HTML template for manager
    redirect_authenticated_user = True  # Redirect logged-in users


# Create a View for all Menu Items where only Manager can add new item. The rest only can read
class MenuItemsView(generics.ListCreateAPIView):
    queryset = MenuItem.objects.all()
    serializer_class = MenuItemSerializer
    permission_classes = [IsManagerOrReadOnly]


class MenuItemCreateView(APIView):
    permission_classes = [IsManagerOrAdminUsers]

    def post(self, request):
        serializer = MenuItemCreateSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


class SingleMenuItemView(generics.RetrieveUpdateDestroyAPIView):
    queryset = MenuItem.objects.all()
    serializer_class = MenuItemSerializer
    permission_classes = [IsManagerOrReadOnly, IsAuthenticated]


class CategoriesView(generics.ListCreateAPIView):
    queryset = Category.objects.all()
    serializer_class = CategorySerializer
    permission_classes = [IsManagerOrAdminUsers]


class CategoriesCreateView(APIView):
    permission_classes = [IsManagerOrAdminUsers]

    def post(self, request):
        serializer = CategoryCreateSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


## View to list all managers and assign a user to the manager group
class ManagerGroupUsersView(APIView):
    permission_classes = [IsAdminUser]  # Add this permission

    def get(self, request):
        manager_group, _ = Group.objects.get_or_create(name="Manager")
        manager_users = manager_group.user_set.all()
        serializer = UserSerializer(manager_users, many=True)
        return Response(serializer.data, status=status.HTTP_200_OK)

    def post(self, request):
        user_id = request.data.get("user_id")

        try:
            user = User.objects.get(id=user_id)
        except User.DoesNotExist:
            return Response(
                {"message": "User not found"}, status=status.HTTP_404_NOT_FOUND
            )

        manager_group, _ = Group.objects.get_or_create(name="Manager")
        user.groups.add(manager_group)
        return Response(
            {"message": "User assigned to Manager group"},
            status=status.HTTP_201_CREATED,
        )

    def delete(self, request):
        user_id = request.data.get("user_id")

        try:
            user = User.objects.get(id=user_id)
        except User.DoesNotExist:
            return Response(
                {"message": "User not found"}, status=status.HTTP_404_NOT_FOUND
            )

        manager_group, _ = Group.objects.get_or_create(name="Manager")
        user.groups.remove(manager_group)
        return Response(
            {"message": "User removed from Manager group"}, status=status.HTTP_200_OK
        )


class ManagerUserList(generics.ListCreateAPIView):
    queryset = User.objects.all()
    serializer_class = UserSerializer
    permission_classes = [IsAuthenticated, IsManagerOrAdminUsers]

    def get_queryset(self):
        managers = Group.objects.get(name="Manager")
        return managers.user_set.all()

    def perform_create(self, serializer):
        manager_group = Group.objects.get(name="Manager")
        user = serializer.save()
        manager_group.user_set.add(user)


## View to assign a user to the manager group
class AssignUserToManager(generics.UpdateAPIView):
    queryset = User.objects.all()
    serializer_class = UserSerializer
    permission_classes = [IsAuthenticated, IsManagerOrAdminUsers]

    def update(self, request, *args, **kwargs):
        user = self.get_object()
        manager_group = Group.objects.get(name="Manager")
        manager_group.user_set.add(user)
        return Response(status=status.HTTP_201_CREATED)


## View to remove a user to the manager group
class RemoveUserFromManager(generics.DestroyAPIView):
    queryset = User.objects.all()
    serializer_class = UserSerializer
    permission_classes = [IsAuthenticated, IsManagerOrAdminUsers]

    def destroy(self, request, *args, **kwargs):
        user = self.get_object()
        manager_group = Group.objects.get(name="Manager")
        manager_group.user_set.remove(user)
        return Response(status=status.HTTP_200_OK)


## View to list all delivery crews and assign a user to the crew group
class DeliveryCrewUserList(generics.ListCreateAPIView):
    queryset = User.objects.all()
    serializer_class = UserSerializer
    permission_classes = [IsAuthenticated, IsManagerOrAdminUsers]

    def get_queryset(self):
        crews = Group.objects.get(name="Crew")
        return crews.user_set.all()

    def perform_create(self, serializer):
        crew_group = Group.objects.get(name="Crew")
        user = serializer.save()
        crew_group.user_set.add(user)


## View to assign a user to the crew group
class AssignUserToDeliveryCrew(generics.UpdateAPIView):
    queryset = User.objects.all()
    serializer_class = UserSerializer
    permission_classes = [IsAuthenticated, IsManagerOrAdminUsers]

    def update(self, request, *args, **kwargs):
        user = self.get_object()
        crew_group = Group.objects.get(name="Crew")
        crew_group.user_set.add(user)
        return Response(status=status.HTTP_201_CREATED)


## View to remove a user to the manager group
class RemoveUserFromDeliveryCrew(generics.DestroyAPIView):
    queryset = User.objects.all()
    serializer_class = UserSerializer
    permission_classes = [IsAuthenticated, IsManagerOrAdminUsers]

    def destroy(self, request, *args, **kwargs):
        user = self.get_object()
        crew_group = Group.objects.get(name="Crew")
        crew_group.user_set.remove(user)
        return Response(status=status.HTTP_200_OK)


## Create the Cart list
class CartListView(generics.ListCreateAPIView):
    queryset = Cart.objects.all()
    serializer_class = CartSerializer

    def get_queryset(self):
        # Retrieve cart items for the authenticated user
        user = self.request.user
        return Cart.objects.filter(user=user)

    def create(self, request, *args, **kwargs):
        # Extract the menu item ID and quantity from the request
        if not request.user.is_authenticated:
            return Response(
                {
                    "Error": "You need a valid user token to place a menu item in the cart"
                },
                status=status.HTTP_401_UNAUTHORIZED,
            )

        # Retrieve the menu item and calculate unit_price and price
        menuitem_id = request.data.get("menuitem")
        quantity = request.data.get("quantity")
        # Ensure 'quantity' is a valid integer
        try:
            quantity = int(quantity)
        except ValueError:
            return Response(
                {"error": "Invalid quantity. Please provide a valid integer."},
                status=status.HTTP_400_BAD_REQUEST,
            )
        menuitem = get_object_or_404(MenuItem, id=menuitem_id)
        unit_price = menuitem.price
        price = unit_price * quantity

        # Create the cart item
        cart_item = Cart.objects.create(
            user=request.user,
            menuitem=menuitem,
            quantity=quantity,
            unit_price=unit_price,
            price=price,
        )

        serializer = CartSerializer(cart_item)

        return Response(serializer.data, status=status.HTTP_201_CREATED)

    def delete(self, request, *args, **kwargs):
        # Delete all cart items for the authenticated user
        user = request.user
        Cart.objects.filter(user=user).delete()
        return Response(status=status.HTTP_204_NO_CONTENT)


class OrderListCreateView(generics.CreateAPIView):
    queryset = Order.objects.all()
    serializer_class = OrderCreateSerializer
    permission_classes = [IsManagerOrAdminUsers, IsOrderOwner]

    def post(self, request):
        # Deserialize the request data using the OrderCreateSerializer
        serializer = OrderCreateSerializer(
            data=request.data, context={"request": request}
        )

        if serializer.is_valid():
            # Calculate the total and create the order
            order_items_data = request.data.get("orderitem_set", [])
            total = Decimal(0)

            for order_item_data in order_items_data:
                menuitem_id = order_item_data.get("menuitem")
                quantity = order_item_data.get("quantity")

                # Calculate unit_price based on the associated menuitem
                menuitem = MenuItem.objects.get(id=menuitem_id)
                unit_price = menuitem.price

                # Ensure that the unit_price is a Decimal
                unit_price = Decimal(unit_price)

                # Calculate the price for the order item
                price = unit_price * quantity
                total += price

                # Set the calculated unit_price in the order item data
                order_item_data["unit_price"] = unit_price
                order_item_data["price"] = price

            # Set the total in the serializer
            serializer.validated_data["total"] = total

            # Set convert_to_order to True
            serializer.validated_data["convert_to_order"] = True

            # Create the order
            order = serializer.save()

            # Create order items associated with the order
            for order_item_data in order_items_data:
                order_item_data["order"] = order.id
                order_item_serializer = OrderItemCreateSerializer(data=order_item_data)
                if order_item_serializer.is_valid():
                    order_item_serializer.save()
                else:
                    return Response(
                        order_item_serializer.errors, status=status.HTTP_400_BAD_REQUEST
                    )

            return Response(
                {"message": "Order created successfully"},
                status=status.HTTP_201_CREATED,
            )
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


# Additional view for retrieving the customer's orders
class OrderListView(generics.ListAPIView):
    queryset = Order.objects.all()
    serializer_class = OrderCreateSerializer
    permission_classes = [IsManagerOrAdminUsers]  # Use an appropriate permission class

    def get_queryset(self):
        if self.request.user.is_customer:
            # Filter orders based on the authenticated customer
            return Order.objects.filter(user=self.request.user)
        return super().get_queryset()


class ItemOfTheDayView(generics.UpdateAPIView):
    queryset = MenuItem.objects.all()
    serializer_class = MenuItemSerializer
    permission_classes = [IsManagerOrAdminUsers]

    def get_object(self):
        # Get the item of the day, which can be the featured item
        return MenuItem.objects.filter(featured=True).first()


class AssignUserToDeliveryCrew(generics.UpdateAPIView):
    queryset = User.objects.all()
    permission_classes = [IsManagerOrAdminUsers]

    def update(self, request, *args, **kwargs):
        user = self.get_object()
        crew_group, created = Group.objects.get_or_create(name="Crew")
        crew_group.user_set.add(user)
        return Response(
            {"message": f"{user.username} is now a Delivery Crew"},
            status=status.HTTP_200_OK,
        )


class AssignOrderToDeliveryCrew(generics.UpdateAPIView):
    queryset = Order.objects.all()
    permission_classes = [IsManagerOrAdminUsers]

    def update(self, request, *args, **kwargs):
        order = self.get_object()
        delivery_crew_group, created = Group.objects.get_or_create(name="Crew")
        # Assuming you have a field to assign a delivery crew member to an order, update it here
        order.delivery_crew = request.user
        order.save()
        return Response(
            {"message": f"Order {order.id} assigned to Delivery Crew"},
            status=status.HTTP_200_OK,
        )


class OrdersAssignedToCrew(generics.ListAPIView):
    serializer_class = OrderCreateSerializer

    def get_queryset(self):
        # Retrieve orders assigned to the current delivery crew (assuming you have a way to track crew members)
        # Replace 'your_crew_member' with an actual reference to the current crew member
        return Order.objects.filter(delivery_crew__username="your_crew_member")


class UpdateOrderStatusView(generics.UpdateAPIView):
    queryset = Order.objects.all()
    serializer_class = UpdateOrderStatusSerializer

    def perform_update(self, serializer):
        serializer.save()  # Save the updated order status

    def update(self, request, *args, **kwargs):
        instance = self.get_object()
        serializer = self.get_serializer(instance, data=request.data)
        serializer.is_valid(raise_exception=True)
        self.perform_update(serializer)
        return Response(serializer.data, status=status.HTTP_200_OK)


class BrowseMenuItemsView(generics.ListAPIView):
    serializer_class = MenuItemSerializer

    def get_queryset(self):
        category_id = self.kwargs.get("category_id")
        query = self.request.query_params.get("query")
        queryset = MenuItem.objects.filter(category=category_id)

        if query:
            # Filter items by both category and search query
            queryset = queryset.filter(Q(title__icontains=query))

        return queryset


class CustomPageNumberPagination(PageNumberPagination):
    page_size = 10
    page_size_query_param = "page_size"
    max_page_size = 100


class BrowseMenuItemsView(generics.ListAPIView):
    serializer_class = MenuItemSerializer
    pagination_class = CustomPageNumberPagination


class BrowseMenuItemsView(generics.ListAPIView):
    serializer_class = MenuItemSerializer
    pagination_class = CustomPageNumberPagination

    def get_queryset(self):
        category_id = self.kwargs.get("category_id")
        query = self.request.query_params.get("query")
        ordering = self.request.query_params.get(
            "ordering", "price"
        )  # Default sorting by price
        queryset = MenuItem.objects.filter(category=category_id)

        if query:
            queryset = queryset.filter(Q(title__icontains=query))

        # Add sorting
        queryset = queryset.order_by(ordering)

        return queryset


@api_view(["GET", "POST"])
@permission_classes([IsAuthenticated])
def manager_users(request):
    if request.method == "GET":
        managers = User.objects.filter(group__name="Manager")
        # Serialize and return the list of managers
        serializer = UserSerializer(managers, many=True)
        return Response(serializer.data, status=status.HTTP_200_OK)

    elif request.method == "POST":
        serializer = AssignManagerSerializer(data=request.data)
        if serializer.is_valid():
            username = serializer.validated_data["username"]
            try:
                user = User.objects.get(username=username)
                manager_group = Group.objects.get(name="Manager")
                user.groups.add(manager_group)
                return Response(
                    {"message": 'f"{username} is now a Manager'},
                    status=status.HTTP_201_CREATED,
                )
            except User.DoesNotExist:
                return Response(
                    {"message": "User not found"}, status=status.HTTP_404_NOT_FOUND
                )
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


@api_view(["DELETE"])
@permission_classes([IsAuthenticated])
def manager_user(request, userId):
    try:
        user = User.objects.get(id=userId)
        manager_group = Group.objects.get(name="Manager")
        user.groups.remove(manager_group)
        return Response(
            {"message": "User remvoed from Manager group"}, status=status.HTTP_200_OK
        )
    except User.DoesNotExist:
        return Response({"message": "User not found"}, status=status.HTTP_404_NOT_FOUND)


@api_view(["GET", "POST"])
@permission_classes([IsAuthenticated])
def delivery_crew_users(request):
    if request.method == "GET":
        delivery_crew = User.objects.filter(group__name="Crew")
        # Serialize and return the list of managers
        serializer = UserSerializer(delivery_crew, many=True)
        return Response(serializer.data, status=status.HTTP_200_OK)

    elif request.method == "POST":
        serializer = AssignManagerSerializer(data=request.data)
        if serializer.is_valid():
            username = serializer.validated_data["username"]
            try:
                user = User.objects.get(username=username)
                manager_group = Group.objects.get(name="Crew")
                user.groups.add(manager_group)
                return Response(
                    {"message": 'f"{username} is now a Delivery Crew'},
                    status=status.HTTP_201_CREATED,
                )
            except User.DoesNotExist:
                return Response(
                    {"message": "User not found"}, status=status.HTTP_404_NOT_FOUND
                )
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


@api_view(["DELETE"])
@permission_classes([IsAuthenticated])
def delivert_crew_user(request, userId):
    try:
        user = User.objects.get(id=userId)
        crew_group = Group.objects.get(name="Crew")
        user.groups.remove(crew_group)
        return Response(
            {"message": "User remvoed from Delivery Crew group"},
            status=status.HTTP_200_OK,
        )
    except User.DoesNotExist:
        return Response({"message": "User not found"}, status=status.HTTP_404_NOT_FOUND)


@api_view(["GET"])
@permission_classes([IsAuthenticated])
def manager_view(request):
    if request.user.groups.filter(name="Manager").exists():
        return Response(
            {"message": "Only Managers have access"}, status=status.HTTP_200_OK
        )  # Only Managers have access
    else:
        return Response(
            {"message": "You are not authorized!"}, status=status.HTTP_403_FORBIDDEN
        )


@api_view(["GET"])
@permission_classes([IsAuthenticated])
def crew_view(request):
    if request.user.groups.filter(name__in=["Crew", "Manager"]).exists():
        return Response(
            {"message": "Only Manager and Delivery Crews have access"},
            status=status.HTTP_200_OK,
        )  # Both the Managers and the Delivery Crews have access
    else:
        return Response(
            {"message": "You are not authorized!"}, status=status.HTTP_403_FORBIDDEN
        )


@api_view(["GET", "POST", "PUT", "DELETE"])
@permission_classes([IsAuthenticated])
def menu_items(request):
    if request.method == "GET":
        items = MenuItem.objects.select_related("category").all()
        serialized_item = MenuItemSerializer(items, many=True)
        return Response(serialized_item.data, status=status.HTTP_200_OK)

    ## Allow only the Manager to edit the menus
    elif request.method == "POST":
        if request.user.groups.filter(name="Manager").exists():
            serialized_item = MenuItemSerializer(data=request.data)
            serialized_item.is_valid(raise_exception=True)
            serialized_item.save()
            return Response(serialized_item.data, status=status.HTTP_201_CREATED)


@api_view(["GET", "PUT", "PATCH", "DELETE"])
@permission_classes([IsAuthenticated, IsManagerOrReadOnly])
def single_item(request, pk):
    item = get_object_or_404(MenuItem, pk=pk)

    if request.method == "GET":
        serialized_item = MenuItemSerializer(item)
        return Response(serialized_item.data, status=status.HTTP_200_OK)

    elif request.method in ["PUT", "PATCH"]:
        if not request.user.groups.filter(name="Manager").exists():
            return Response(
                {"message": "You are not able to edit menu item"},
                status=status.HTTP_403_FORBIDDEN,
            )
        else:
            serialized_item = MenuItemSerializer(item, data=request.data, partial=True)
            if serialized_item.is_valid():
                serialized_item.save()
                return Response(serialized_item.data, status=status.HTTP_201_OK)

    elif request.method == "DELETE":
        if not request.user.groups.filter(name="Manager").exists():
            return Response(
                {"message": "You are not allowed to delete menu item"},
                status=status.HTTP_403_FORBIDDEN,
            )
        else:
            item.delete()
            return Response(
                {"message": "The menu item has been deleted"},
                status=status.HTTP_204_NO_CONTENT,
            )
