from rest_framework import serializers
from .models import MenuItem, Category, Cart, Order, OrderItem
from django.contrib.auth.models import User, Group


class AssignManagerSerializer(serializers.Serializer):
    username = serializers.CharField()


class AssignCrewSerializer(serializers.Serializer):
    username = serializers.CharField()


class CategorySerializer(serializers.ModelSerializer):
    class Meta:
        model = Category
        fields = ["id", "title"]


class CategoryCreateSerializer(serializers.ModelSerializer):
    class Meta:
        model = Category
        fields = ["id", "title"]


class MenuItemSerializer(serializers.ModelSerializer):
    category = serializers.StringRelatedField(read_only=True)
    category_id = serializers.IntegerField(write_only=True)

    class Meta:
        model = MenuItem
        fields = ["id", "title", "price", "featured", "category", "category_id"]


class MenuItemCreateSerializer(serializers.ModelSerializer):
    class Meta:
        model = MenuItem
        fields = ["id", "title", "price", "featured", "category", "category_id"]


class UserSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ["id", "username", "email", "first_name", "last_name"]


class CartSerializer(serializers.ModelSerializer):
    class Meta:
        model = Cart
        fields = ["id", "user", "menuitem", "quantity", "unit_price", "price"]


# Serializer for creating an order item
class OrderItemCreateSerializer(serializers.ModelSerializer):
    class Meta:
        model = OrderItem
        fields = ["menuitem", "quantity", "unit_price", "price"]


# Serializer for creating an order
class OrderCreateSerializer(serializers.ModelSerializer):
    # Include orderitem_set for creating order items
    orderitem_set = OrderItemCreateSerializer(many=True)

    class Meta:
        model = Order
        fields = ["orderitem_set", "total"]

    def create(self, validated_data):
        # Extract orderitem_set data
        order_items_data = validated_data.pop("orderitem_set")

        # Create the order with the current user
        order = Order.objects.create(
            user=self.context["request"].user, total=validated_data.get("total")
        )

        # Create order items for the order
        for order_item_data in order_items_data:
            OrderItem.objects.create(order=order, **order_item_data)

        return order


from rest_framework import serializers


class UpdateOrderStatusSerializer(serializers.Serializer):
    delivered = serializers.BooleanField()
